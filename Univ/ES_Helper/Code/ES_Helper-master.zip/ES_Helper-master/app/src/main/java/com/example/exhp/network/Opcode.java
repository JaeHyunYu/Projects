package com.example.exhp.network;

public enum Opcode {
    LoginRequest,
    RegisterRequest,
    SurveyRequest,
    LocationRequest,
    ParseRequest,
    ImageRequest,
    WikiRequest
}
