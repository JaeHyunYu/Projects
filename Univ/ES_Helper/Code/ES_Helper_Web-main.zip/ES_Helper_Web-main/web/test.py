from konlpy.tag import Okt

okt=Okt()

print(okt.nouns("순천고추장"))
